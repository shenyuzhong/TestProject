﻿using UnityEngine;
using System.Collections;
using System.Runtime.InteropServices;
using System.IO;
using System;

public class EqDisplay : MonoBehaviour {

    public Sprite[] eqSprites;
    public int counter = 0;
    public Color origEqColor;
    
	// Use this for initialization
	void Start () {
        int varSize = 100;
        char[] uResult = new char[varSize];

        CallCPPFunc.CallCPPFunc.PyInit();

		CallCPPFunc.polyExpression quadCurve = new CallCPPFunc.polyExpression();

		quadCurve.CHorizShift = 2;//c
		quadCurve.AVertStretch = 1;//a
		quadCurve.BHorizStretch = 1;//b
		quadCurve.DVerticalShift =1;//d
		quadCurve.ResourceFolder = "Equation Images";
		quadCurve.FileName = "newEQ.png";

		quadCurve.setEqColor (1, 1, 0);

		quadCurve.generateEqImage();

		//Debug.Log (quadCurve.REqColor.ToString ());//quadCurve.ExprString);

		//Debug.Log (System.Environment.Version);

        //CallCPPFunc.CallCPPFunc.PyCallGenEqSharp("genEQ", "genPNG", quadCurve.ExprString.ToCharArray(), origEqColor.r.ToString().ToCharArray(), origEqColor.g.ToString().ToCharArray(), origEqColor.b.ToString().ToCharArray(), origEqColor.a.ToString().ToCharArray(), "300".ToCharArray(), "Equation Images".ToCharArray(), "test1.png".ToCharArray(), uResult);

    }
	
	// Update is called once per frame
	void Update () {

        if (Input.GetKeyDown(KeyCode.Space))
        {
            counter = 1;
            
        }

        if (Input.GetKeyDown(KeyCode.A))
        {
            origEqColor.r = UnityEngine.Random.value;
            origEqColor.g = UnityEngine.Random.value;
            origEqColor.b = UnityEngine.Random.value;
            char[] uResult = new char[100];
            CallCPPFunc.CallCPPFunc.PyCallGenEqSharp("genEQ", "genPNG", "x**2-5".ToCharArray(), origEqColor.r.ToString().ToCharArray(), origEqColor.g.ToString().ToCharArray(), origEqColor.b.ToString().ToCharArray(), origEqColor.a.ToString().ToCharArray(), "300".ToCharArray(), "Equation Images".ToCharArray(), "test1.png".ToCharArray(), uResult);
        }

        UnityEditor.AssetDatabase.Refresh();

        eqSprites = Resources.LoadAll<Sprite>("Equation Images");

        gameObject.GetComponent<SpriteRenderer>().sprite = eqSprites[counter];

        
	
	}
}
