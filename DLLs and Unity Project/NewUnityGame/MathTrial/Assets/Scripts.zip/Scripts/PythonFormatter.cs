﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.IO;
using UnityEngine.UI;
public class PythonFormatter : MonoBehaviour {

    List<GameObject> UserHistory = new List<GameObject>();
    public int UserHistoryMemorySize;
    //upon any change to the input variables we are Instantiating a UserInput Class, populating it, then updating our UserHistory
    private int totalObjects = 0;
    public GameObject VariableA_ref;
    public GameObject VariableB_ref;
    public GameObject VariableC_ref;
    public GameObject VariableD_ref;
    public GameObject Equation_Output_ref;
    public GameObject Plot_Output_ref;
    public GameObject DebugEquation;
    public GameObject DebugListCount;
    public GameObject NewEq_prefab_ref;
    public GameObject HoldEquationObjects;
	public int varSize = 100;
	public char[] uResult;
	void Awake(){
		CallCPPFunc.CallCPPFunc.PyInit();
		int varSize = 100;
		uResult = new char[varSize];
	}
    public void Modification()
    {
        GameObject NewEquationObject = Instantiate(NewEq_prefab_ref, Vector3.zero, Quaternion.identity) as GameObject;
        NewEquationObject.name = "Equation_" + totalObjects.ToString(); 
        NewEquationObject.GetComponent<UserEquationInput>().Initialize(VariableA_ref.GetComponent<UpdateValue>().ReturnVariable(),
            VariableB_ref.GetComponent<UpdateValue>().ReturnVariable(),
            VariableC_ref.GetComponent<UpdateValue>().ReturnVariable(),
            VariableD_ref.GetComponent<UpdateValue>().ReturnVariable(),
            Color.blue
            );
        totalObjects++;
        NewEquationObject.transform.parent = HoldEquationObjects.transform;
        //here is where we can pull the info for the equations
        string equationRoot = NewEquationObject.GetComponent<UserEquationInput>().AssetFileRootName;
        string equation_plot = equationRoot + "_PLOT.png";
        string equation_EQ = equationRoot + "_EQ.png";
		string equationTest = equationRoot + "_EQ";
		string plotTest = equationRoot + "_PLOT";
		PythonEquationGenerator (NewEquationObject, equation_EQ,equationTest);
		PythonPlotGenerator (NewEquationObject, equation_plot, plotTest);
        //update and manage current list
        UserHistory.Add(NewEquationObject);
        UserHistoryManagement();
    }
    private void UserHistoryManagement()
    {
        if (UserHistory.Count > UserHistoryMemorySize)
        {
            Destroy(UserHistory[0]);
            UserHistory.RemoveAt(0);
        }
        //Display Most Recent Equation only for debugging purposes
        DebugEquation.GetComponent<Text>().text = UserHistory[UserHistory.Count - 1].GetComponent<UserEquationInput>().CurrentPythonEq;
        DebugListCount.GetComponent<Text>().text = "List Length: " + UserHistory.Count.ToString();
    }
	private void PythonEquationGenerator(GameObject equationObject, string fileName, string testImageName){
		CallCPPFunc.polyExpression quadCurve = new CallCPPFunc.polyExpression();

		quadCurve.AVertStretch = equationObject.GetComponent<UserEquationInput> ().VarA;
		quadCurve.BHorizStretch = equationObject.GetComponent<UserEquationInput> ().VarB;
		quadCurve.CHorizShift = equationObject.GetComponent<UserEquationInput> ().VarC;
		quadCurve.DVerticalShift = equationObject.GetComponent<UserEquationInput> ().VarD;

		quadCurve.ResourceFolder = "Equation Images";
		quadCurve.FileName = fileName;

		quadCurve.setEqColor(equationObject.GetComponent<UserEquationInput>().CurrentColor.r,equationObject.GetComponent<UserEquationInput>().CurrentColor.g,equationObject.GetComponent<UserEquationInput>().CurrentColor.b);

		//create PNG for Equation
		quadCurve.generateEqImage ();
		//CallCPPFunc.CallCPPFunc.PyCallGenEqSharp("genEQ", "genPNG", quadCurve.ExprString.ToCharArray(), quadCurve.REqColor.ToString().ToCharArray(), quadCurve.GEqColor.ToString().ToCharArray(),quadCurve.BEqColor.ToString().ToCharArray(), "0".ToCharArray(), "300".ToCharArray(), quadCurve.ResourceFolder.ToCharArray(), quadCurve.FileName.ToCharArray(), uResult);
		//grab image from file and display
		UnityEditor.AssetDatabase.Refresh();

		string rootF = "Equation Images/" + testImageName;
		Sprite myEquation_image = Resources.Load(rootF, typeof(Sprite)) as Sprite;
		//Debug.Log (rootF);
		Equation_Output_ref.GetComponent<Image> ().sprite = myEquation_image;

	}
	private void PythonPlotGenerator(GameObject equationObject, string fileName, string testImageName)
	{
		CallCPPFunc.Plot newCurve = new CallCPPFunc.Plot();
		
		newCurve.Expr = "1*(1*x+0)**2+0";
		//newCurve.Expr = equationObject.GetComponent<UserEquationInput> ().CurrentPythonEq;

		//Debug.Log (newCurve.Expr);

		CallCPPFunc.PlotAxes newGraph = new CallCPPFunc.PlotAxes();
		newGraph.AddCurve(newCurve);

		newGraph.ResourceFolder = "Plot Figures";
		newGraph.FileName = "newGRAPH.png";
		newGraph.FileName = fileName;

		newGraph.generateGrid();
		newGraph.generatePlot(0);
	

		UnityEditor.AssetDatabase.Refresh();
		string rootF = "Plot Figures/" + testImageName+"_AXES";
		Sprite myPlot_image = Resources.Load(rootF, typeof(Sprite)) as Sprite;

		Plot_Output_ref.GetComponent<Image> ().sprite = myPlot_image;
	}

}
