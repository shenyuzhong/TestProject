﻿using UnityEngine;
using System.Collections;

public class PlotDisplay : MonoBehaviour {

    public Sprite[] plotSprites;
    public int counter = 0;
    public Color plotColor;
    public float xPoint;

	// Use this for initialization
	void Start () {
        
	}
	
	// Update is called once per frame
	void Update () {
        if (Input.GetKeyDown(KeyCode.L))
        {
            CallCPPFunc.Plot newCurve = new CallCPPFunc.Plot();

			//newCurve.Expr = "x**2";

			CallCPPFunc.PlotAxes newGraph = new CallCPPFunc.PlotAxes();
			newGraph.AddCurve(newCurve);



			newGraph.ResourceFolder = "Plot Figures";
			newGraph.FileName = "newGRAPH.png";

			newGraph.generateGrid();
			newGraph.generatePlot(0);

            UnityEditor.AssetDatabase.Refresh();

            plotSprites = Resources.LoadAll<Sprite>("Plot Figures");

            gameObject.GetComponent<SpriteRenderer>().sprite = plotSprites[counter];
        }
	}
}
